// Assertion tests for the local note writer's runtime half.
//
// Everything here runs against real files — a real zip, real hashes, a real spooled
// directory — because the parts worth testing are the ones that touch the disk: whether
// a ".part" can be mistaken for a model, whether an archive can escape its directory,
// and whether a missing platform says so instead of downloading a wrong binary.
import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { spawn } from 'node:child_process'
import { existsSync, lstatSync, mkdirSync, mkdtempSync, readdirSync, readFileSync, readlinkSync, statSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { deflateRawSync, gzipSync } from 'node:zlib'
import * as L from '../local.js'

const root = mkdtempSync(join(tmpdir(), 'dsh-ccd-local-'))

// ── platform table ────────────────────────────────────────────────────────

assert.equal(L.runtimeFor('win32', 'x64').exe, 'llama-server.exe')
assert.equal(L.runtimeFor('linux', 'x64').exe, 'llama-server', 'the Linux build has no .exe suffix')
assert.equal(L.runtimeFor('linux', 'arm64').archive, 'tar.gz')
assert.equal(L.runtimeFor('darwin', 'arm64'), undefined, 'an unpinned platform has no runtime')

for (const [platform, arch] of [['win32', 'x64'], ['linux', 'x64'], ['linux', 'arm64']]) {
  const pinned = L.runtimeFor(platform, arch)
  assert.ok(pinned.bytes > 0, `${platform}-${arch} is pinned by size`)
  assert.match(pinned.sha256, /^[0-9a-f]{64}$/, `${platform}-${arch} is pinned by digest`)
  const listed = L.assetsFor({}, platform, arch)
  assert.deepEqual(listed.map((asset) => asset.kind), ['runtime', 'model'])
  // The pinned asset must be the one the downloader would fetch, byte for byte.
  assert.equal(listed[0].bytes, pinned.bytes)
  assert.equal(listed[0].sha256, pinned.sha256)
}
// A platform with no runtime still offers the model: the model is platform-independent,
// and hiding it would only postpone the news to start time.
assert.deepEqual(L.assetsFor({}, 'darwin', 'arm64').map((asset) => asset.kind), ['model'])

const assets = L.assetsFor({}, 'win32', 'x64')

// ── estimate ──────────────────────────────────────────────────────────────

const estimate = L.setupEstimate({}, 'win32', 'x64')
const total = assets.reduce((sum, asset) => sum + asset.bytes, 0)
assert.ok(estimate.recommendedDiskBytes >= total, 'the estimate covers the assets themselves')
assert.ok(estimate.recommendedDiskBytes < total * 2, 'and is not padded into nonsense')
assert.ok(estimate.expectedMemoryBytes > 0)
assert.ok(estimate.minimumMinutes <= estimate.maximumMinutes)

// ── unzip ─────────────────────────────────────────────────────────────────
// The archive is built here rather than checked in: a zip this file can construct is a
// zip this file can also explain when it fails.

function buildZip(entries) {
  const locals = []
  const centrals = []
  let offset = 0
  for (const [name, content] of entries) {
    const raw = Buffer.from(content)
    const packed = deflateRawSync(raw)
    const nameBytes = Buffer.from(name)
    const local = Buffer.alloc(30)
    local.writeUInt32LE(0x04034b50, 0)
    local.writeUInt16LE(20, 4)
    local.writeUInt16LE(8, 8)
    local.writeUInt32LE(packed.length, 18)
    local.writeUInt32LE(raw.length, 22)
    local.writeUInt16LE(nameBytes.length, 26)
    const central = Buffer.alloc(46)
    central.writeUInt32LE(0x02014b50, 0)
    central.writeUInt16LE(20, 4)
    central.writeUInt16LE(20, 6)
    central.writeUInt16LE(8, 10)
    central.writeUInt32LE(packed.length, 20)
    central.writeUInt32LE(raw.length, 24)
    central.writeUInt16LE(nameBytes.length, 28)
    central.writeUInt32LE(offset, 42)
    locals.push(local, nameBytes, packed)
    centrals.push(central, nameBytes)
    offset += local.length + nameBytes.length + packed.length
  }
  const directory = Buffer.concat(centrals)
  const end = Buffer.alloc(22)
  end.writeUInt32LE(0x06054b50, 0)
  end.writeUInt16LE(entries.length, 8)
  end.writeUInt16LE(entries.length, 10)
  end.writeUInt32LE(directory.length, 12)
  end.writeUInt32LE(offset, 16)
  return Buffer.concat([...locals, directory, end])
}

const archive = buildZip([
  ['llama-server.exe', 'binary content here'],
  ['nested/ggml-base.dll', 'a dll that lives in a subdirectory'],
])
const unzipped = join(root, 'unzip')
const written = await L.unzip(archive, unzipped)
// Entries land under their base name: an archive is untrusted input, and a nested path
// is exactly how a zip escapes the directory it is unpacked into.
assert.deepEqual(written.sort(), ['ggml-base.dll', 'llama-server.exe'])
assert.equal(readFileSync(join(unzipped, 'llama-server.exe'), 'utf8'), 'binary content here')
assert.equal(existsSync(join(unzipped, 'nested')), false)

const escaping = buildZip([['../../escaped.txt', 'should not be here']])
await L.unzip(escaping, join(root, 'escape'))
assert.equal(existsSync(join(root, 'escaped.txt')), false, 'a traversal name stays inside the target')
assert.equal(existsSync(join(unzipped, 'escaped.txt')), false)

await assert.rejects(() => L.unzip(Buffer.from('not a zip at all'), join(root, 'junk')), /central directory/)

// ── classifyDownloadFailure ───────────────────────────────────────────────
// The reader gets a sentence, not an errno.

assert.equal(L.classifyDownloadFailure({ code: 'ENOSPC' }).reason, 'storage')
assert.equal(L.classifyDownloadFailure({ code: 'EACCES' }).reason, 'storage')
assert.equal(L.classifyDownloadFailure({ code: 'ENOTFOUND' }).reason, 'dns')
assert.equal(L.classifyDownloadFailure({ code: 'ETIMEDOUT' }).reason, 'timeout')
assert.equal(L.classifyDownloadFailure(new Error('socket hang up')).reason, 'network')
assert.equal(L.classifyDownloadFailure(new Error('certificate has expired')).reason, 'certificate')
assert.equal(L.classifyDownloadFailure({ code: 'INTEGRITY' }).reason, 'integrity')
assert.equal(L.classifyDownloadFailure(new Error('who knows')).reason, 'unknown')
assert.equal(L.classifyDownloadFailure(undefined).reason, 'unknown')

// ── inspectRuntime ────────────────────────────────────────────────────────

const empty = await L.inspectRuntime(join(root, 'nothing-yet'), 'win32', 'x64')
assert.equal(empty.phase, 'unprepared')
assert.deepEqual(empty.missing, ['runtime', 'model'])
assert.equal((await L.inspectRuntime(root, 'darwin', 'arm64')).phase, 'unsupported')

const layout = L.layoutOf(join(root, 'prepared'))
mkdirSync(layout.runtimeDir, { recursive: true })
mkdirSync(join(layout.root, 'models'), { recursive: true })
writeFileSync(join(layout.runtimeDir, L.runtimeFor('win32', 'x64').exe), 'x')
assert.deepEqual((await L.inspectRuntime(layout.root, 'win32', 'x64')).missing, ['model'])
// A model of the wrong size is not "probably fine": it is a different file.
writeFileSync(layout.model, 'too small')
assert.deepEqual((await L.inspectRuntime(layout.root, 'win32', 'x64')).missing, ['model'])
const modelAsset = assets[1]
writeFileSync(layout.model, Buffer.alloc(modelAsset.bytes))
assert.equal((await L.inspectRuntime(layout.root, 'win32', 'x64')).phase, 'ready')

// ── downloadAsset ─────────────────────────────────────────────────────────

// An already-correct file is reused with no network at all: the URL below cannot
// resolve, so reaching the assertion proves the short circuit ran first.
const reuse = join(root, 'reuse.bin')
writeFileSync(reuse, 'exact bytes')
const reuseAsset = {
  kind: 'model',
  name: 'reuse.bin',
  bytes: Buffer.byteLength('exact bytes'),
  sha256: createHash('sha256').update('exact bytes').digest('hex'),
}
const events = []
const kept = await L.downloadAsset(reuseAsset, reuse, 'http://127.0.0.1:1/nope', new AbortController().signal, (event) => events.push(event.phase))
assert.equal(kept, reuse)
assert.deepEqual(events, ['ready'])

// A file of the right size with the wrong content is not reused either.
const wrong = join(root, 'wrong.bin')
writeFileSync(wrong, 'exact bytes')
await assert.rejects(
  () => L.downloadAsset({ ...reuseAsset, sha256: 'f'.repeat(64) }, wrong, 'http://127.0.0.1:1/nope', new AbortController().signal, () => {}),
  // The download is attempted, and the unreachable URL is what fails it.
  (error) => error !== undefined,
)
// No ".part" survives a failed attempt: a half file must never be resumable by accident.
assert.deepEqual(readdirSync(root).filter((name) => name.endsWith('.part')), [])

// ── untar ─────────────────────────────────────────────────────────────────
// Built here for the same reason as the zip: an archive this file can construct is one
// this file can explain when it fails. The real Linux builds are tarballs carrying
// symlinks and executable bits, and those two are exactly what a zip extractor loses.

function octal(value, width) {
  const text = value.toString(8)
  return `${'0'.repeat(width - 1 - text.length)}${text}${String.fromCharCode(0)}`
}

function tarHeader({ name, size, type, mode, link }) {
  const header = Buffer.alloc(512)
  header.write(name, 0, 'utf8')
  header.write(octal(mode ?? 0o644, 8), 100, 'utf8')
  header.write(octal(0, 8), 108, 'utf8')
  header.write(octal(0, 8), 116, 'utf8')
  header.write(octal(size, 12), 124, 'utf8')
  header.write(octal(0, 12), 136, 'utf8')
  header.write(type, 156, 'utf8')
  if (link !== undefined) header.write(link, 157, 'utf8')
  header.write('ustar', 257, 'utf8')
  header.write('00', 263, 'utf8')
  // The checksum is computed with its own field read as spaces, which is why it is written
  // twice: once blank for the sum, then for real.
  header.write('        ', 148, 'utf8')
  let sum = 0
  for (const byte of header) sum += byte
  header.write(`${sum.toString(8).padStart(6, '0')}${String.fromCharCode(0)} `, 148, 'utf8')
  return header
}

function buildTar(entries) {
  const blocks = []
  for (const entry of entries) {
    const body = Buffer.from(entry.content ?? '')
    blocks.push(tarHeader({ ...entry, size: body.length }))
    if (body.length > 0) {
      blocks.push(body)
      const pad = (512 - (body.length % 512)) % 512
      if (pad > 0) blocks.push(Buffer.alloc(pad))
    }
  }
  // Two zero blocks end an archive.
  blocks.push(Buffer.alloc(1024))
  return gzipSync(Buffer.concat(blocks))
}

{
  const archive = buildTar([
    { name: 'llama-b12015/', type: '5', mode: 0o755 },
    { name: 'llama-b12015/llama-server', type: '0', mode: 0o755, content: 'ELF payload' },
    { name: 'llama-b12015/libllama.so.0.8.0', type: '0', mode: 0o644, content: 'shared object' },
    { name: 'llama-b12015/libllama.so.0', type: '2', link: 'libllama.so.0.8.0' },
    // A link that points outside the extracted folder is dropped: flattened, it would
    // reach somewhere the archive never contained.
    { name: 'llama-b12015/escape', type: '2', link: '../../../etc/passwd' },
    { name: 'llama-b12015/absolute', type: '2', link: '/etc/passwd' },
    // Traversal in a plain name is flattened away rather than followed.
    { name: 'llama-b12015/../../escaped.txt', type: '0', content: 'nope' },
  ])
  const out = join(root, 'untar')
  const written = await L.untar(archive, out)
  assert.ok(written.includes('llama-server'), 'the server binary is missing')
  assert.equal(readFileSync(join(out, 'llama-server'), 'utf8'), 'ELF payload')
  // The executable bit is the reason this is not the zip path: without it the server
  // cannot be started at all.
  // Windows has no executable bit to keep: `stat` there reports a fixed mode, so the
  // question only has an answer on the platform this path exists for.
  if (process.platform !== 'win32') {
    assert.equal(statSync(join(out, 'llama-server')).mode & 0o111, 0o111, 'lost the executable bit')
  }
  assert.equal(readlinkSync(join(out, 'libllama.so.0')), 'libllama.so.0.8.0')
  assert.equal(lstatSync(join(out, 'libllama.so.0')).isSymbolicLink(), true)
  assert.equal(existsSync(join(out, 'escape')), false, 'an escaping symlink was created')
  assert.equal(existsSync(join(out, 'absolute')), false, 'an absolute symlink was created')
  assert.equal(existsSync(join(root, 'escaped.txt')), false, 'a traversal name escaped the folder')
  assert.equal(existsSync(join(out, 'escaped.txt')), true, 'the traversal was not flattened')

  await assert.rejects(() => L.untar(Buffer.from('not gzip'), join(root, 'untar-junk')))
}

// ── orderSources ──────────────────────────────────────────────────────────

assert.deepEqual(await L.orderSources('/x', ['https://only.example'], 1000, undefined), ['https://only.example'])
// Every probe fails here, and the original order comes back — a bad network never
// empties the source list.
const dead = await L.orderSources('/x', ['https://a.example', 'https://b.example'], 50, undefined)
assert.deepEqual(dead.sort(), ['https://a.example', 'https://b.example'])

// ── layout ────────────────────────────────────────────────────────────────

const fixed = L.layoutOf('/data')
// The archive is a scratch file whose name follows the platform, so the layout exposes the
// folder rather than a fixed file name.
assert.equal(fixed.runtimeRoot, join('/data', 'runtime'))
assert.equal(fixed.runtimeDir, join('/data', 'runtime', 'bin'))
assert.ok(fixed.model.startsWith(join('/data', 'models')))
assert.ok(fixed.model.endsWith('.gguf'))

// ── the platform answer the card reads ────────────────────────────────────

{
  // `supported` is what the page keys off instead of re-deriving it from the phase, so the
  // two halves cannot disagree. The rest of the plugin is unaffected: the provider route
  // needs no runtime, and every other setting keeps working on a platform with no build.
  const src = readFileSync(new URL('../index.js', import.meta.url), 'utf8')
  assert.match(src, /supported: runtimeFor\(platform, arch\) !== undefined/, 'localView does not report support')
  assert.match(src, /has no pinned runtime/, 'the prepare route does not refuse an unsupported platform')
}

// ── removeRuntime ─────────────────────────────────────────────────────────

{
  // A prepared root: the unpacked runtime, plus the model.
  const prepared = join(root, 'remove-prepared')
  mkdirSync(join(prepared, 'runtime', 'bin'), { recursive: true })
  mkdirSync(join(prepared, 'models'), { recursive: true })
  writeFileSync(join(prepared, 'runtime', 'bin', 'llama-server.exe'), 'MZ')
  writeFileSync(join(prepared, 'runtime', 'llama-b12015-bin-ubuntu-x64.tar.gz'), 'archive')
  writeFileSync(join(prepared, 'models', L.modelFile('Q4_K_M')), 'gguf')
  // Something the reader put there, which this plugin must not touch.
  writeFileSync(join(prepared, 'notes.txt'), 'mine')

  await L.removeRuntime(prepared)

  assert.equal(existsSync(join(prepared, 'runtime')), false, 'the runtime directory survived')
  assert.equal(existsSync(join(prepared, 'models', L.modelFile('Q4_K_M'))), false, 'the model survived')
  assert.equal(existsSync(join(prepared, 'notes.txt')), true, 'a reader file was deleted too')
  assert.equal(existsSync(prepared), true, 'the data root itself was deleted')
  const verdict = await L.inspectRuntime(prepared, 'win32', 'x64')
  assert.equal(verdict.phase, 'unprepared')
}

{
  // A reader's own GGUF sitting next to ours: the models directory stays, because it is
  // not empty and this plugin did not create what is in it.
  const shared = join(root, 'remove-shared')
  mkdirSync(join(shared, 'models'), { recursive: true })
  writeFileSync(join(shared, 'models', 'someone-elses.gguf'), 'gguf')
  await L.removeRuntime(shared)
  assert.equal(existsSync(join(shared, 'models', 'someone-elses.gguf')), true)
}

{
  // Nothing there at all: removing is a no-op, not a throw. The button stays visible on a
  // half-downloaded root, so a reader can press it twice.
  const empty = join(root, 'remove-empty')
  await L.removeRuntime(empty)
  await L.removeRuntime(empty)
  assert.equal(existsSync(empty), false)
}

// ── quantisations ─────────────────────────────────────────────────────────

{
  // Every name in the table must resolve to a file name, a size and a digest. Two tunes of
  // the same base are on offer, so the table is checked against that split rather than
  // against "the small ones are imatrix": sizes overlap between the two fine-tunes.
  assert.ok(L.QUANTS.length >= 5, 'the quantisation table is suspiciously short')
  const HERETIC = 2
  const SHARP = 4
  assert.equal(L.QUANTS.filter((quant) => quant.variant === 'heretic').length, HERETIC)
  assert.equal(L.QUANTS.filter((quant) => quant.variant === 'sharp').length, SHARP)
  for (const quant of L.QUANTS) {
    assert.match(quant.name, /^[A-Za-z0-9_]+$/, `${quant.name} is not a plain quant name`)
    assert.equal(L.modelFile(quant.name), quant.file, `${quant.name} does not resolve to its own file`)
    assert.equal(L.quantFor(quant.name).sha256, quant.sha256)
    assert.ok(quant.bytes > 1e8, `${quant.name} has no plausible size`)
    assert.ok(quant.bits > 2 && quant.bits < 12, `${quant.name} has an implausible bit count`)
    assert.ok(quant.file.endsWith('.gguf'), `${quant.name} does not point at a GGUF`)
    // The two ends are the abliterated tune, the ladder in between is the sharp one.
    assert.ok(['heretic', 'sharp'].includes(quant.variant), `${quant.name} has no variant`)
    assert.equal(quant.imatrix, quant.variant === 'sharp', `${quant.name} disagrees with its repository about imatrix`)
  }
  // The two tunes must not collide on a file name, or the inventory would conflate them.
  assert.equal(new Set(L.QUANTS.map((quant) => quant.file)).size, L.QUANTS.length)
  // The default and the top end come from the abliterated repository.
  assert.equal(L.quantFor(L.DEFAULT_QUANT).variant, 'heretic')
  assert.equal(L.quantFor(L.QUANTS.at(-1).name).variant, 'heretic')
  // Sizes increase with bits: a table where they do not is one where a name got swapped.
  const sizes = L.QUANTS.map((quant) => quant.bytes)
  assert.deepEqual(sizes, [...sizes].sort((a, b) => a - b), 'the quantisations are out of order')

  // An unknown name is the default, not a crash: the profile may have been written by an
  // older build that offered something this one does not.
  assert.equal(L.quantFor('nope'), L.quantFor(L.DEFAULT_QUANT))
  assert.equal(L.modelFile('nope'), L.modelFile(L.DEFAULT_QUANT))
  assert.equal(L.quantFor(undefined).name, L.DEFAULT_QUANT)

  // File name → quant name, used to report what is already on disk.
  assert.equal(L.quantOfFile(L.modelFile(L.QUANTS[0].name)), L.QUANTS[0].name)
  assert.equal(L.quantOfFile('someone-elses.gguf'), undefined)

  // The estimate follows the chosen quantisation, because the download does.
  const small = L.setupEstimate({ quant: L.QUANTS[0].name }, 'win32', 'x64')
  const large = L.setupEstimate({ quant: 'Q8_0' }, 'win32', 'x64')
  assert.ok(large.recommendedDiskBytes > small.recommendedDiskBytes, 'the estimate ignores the quantisation')

  // Only this plugin's own files are reported, so a delete never takes a reader's file.
  const mixed = join(root, 'quant-mixed')
  mkdirSync(join(mixed, 'models'), { recursive: true })
  writeFileSync(join(mixed, 'models', L.modelFile('Q4_K_M')), 'ours')
  writeFileSync(join(mixed, 'models', 'someone-elses.gguf'), 'theirs')
  const ours = await L.modelsOnDisk(mixed)
  assert.deepEqual(ours, [L.modelFile('Q4_K_M')], 'the inventory is not exactly the files this plugin wrote')

  // "Delete files" clears every quantisation of ours and nothing else. Several can be
  // sitting there at once, because switching is how a reader compares two: keeping them is
  // the feature, so the only thing that removes them is this explicit press.
  const swap = join(root, 'quant-swap')
  mkdirSync(join(swap, 'models'), { recursive: true })
  writeFileSync(join(swap, 'models', L.modelFile('Q4_K_M')), 'one')
  writeFileSync(join(swap, 'models', L.modelFile('Q8_0')), 'two')
  writeFileSync(join(swap, 'models', 'someone-elses.gguf'), 'theirs')
  assert.equal((await L.modelsOnDisk(swap)).length, 2, 'both quantisations should be inventoried')
  await L.removeRuntime(swap)
  assert.equal(existsSync(join(swap, 'models', L.modelFile('Q4_K_M'))), false, 'a quantisation survived the delete')
  assert.equal(existsSync(join(swap, 'models', L.modelFile('Q8_0'))), false, 'a quantisation survived the delete')
  assert.equal(existsSync(join(swap, 'models', 'someone-elses.gguf')), true, 'a reader file was deleted')

  // A model this build no longer offers is still this plugin's file. Changing the table
  // without this would strand the previous default on disk: not reported by the
  // inventory, and therefore not deleted by "delete files" either.
  const RETIRED_FILE = 'Bellatrix-Tiny-1.5B-R1.i1-Q4_K_M.gguf'
  assert.equal(L.isOwnModelFile(RETIRED_FILE), true, 'a retired model is not recognised as ours')
  const stale = join(root, 'quant-stale')
  mkdirSync(join(stale, 'models'), { recursive: true })
  writeFileSync(join(stale, 'models', RETIRED_FILE), 'stale')
  assert.deepEqual(await L.modelsOnDisk(stale), [RETIRED_FILE], 'a retired model is invisible to the inventory')
  await L.removeRuntime(stale)
  assert.equal(existsSync(join(stale, 'models', RETIRED_FILE)), false, 'the retired model was left behind')
  // No current file name may collide with a retired one, or one release would delete the
  // model another release just downloaded.
  for (const quant of L.QUANTS) assert.notEqual(quant.file, RETIRED_FILE)
}

// ── a runtime that cannot start ───────────────────────────────────────────

{
  // The failure that took the host down: `writer: local` with the files deleted. `spawn`
  // reports it through an `error` event, and an unheard `error` on a ChildProcess is an
  // uncaught exception — which in this host means the whole app. Both shapes are covered:
  // nothing there at all, and a file that exists but is not an executable.
  const gone = join(root, 'spawn-gone')
  const absent = new L.LocalRuntime({ dataRoot: gone, platform: process.platform, arch: process.arch, quant: 'Q4_K_M', threads: 2, contextSize: 2048 })
  // Only one platform has a pinned runtime, so this asserts the shape that applies here
  // rather than a Windows-only message: the point is that `ensure` rejects at all instead of
  // leaving a caller waiting on a process that will never exist.
  if (L.runtimeFor(process.platform, process.arch) === undefined) {
    await assert.rejects(() => absent.ensure(), /no pinned runtime/)
  } else {
    await assert.rejects(() => absent.ensure(), (error) => error.code === 'NOT_PREPARED')
  }
  assert.equal(absent.status().running, false)

  const broken = join(root, 'spawn-broken')
  mkdirSync(join(broken, 'runtime', 'bin'), { recursive: true })
  mkdirSync(join(broken, 'models'), { recursive: true })
  writeFileSync(join(broken, 'runtime', 'bin', 'llama-server.exe'), 'not a program')
  writeFileSync(join(broken, 'models', L.modelFile('Q4_K_M')), 'not weights')
  const runtime = new L.LocalRuntime({ dataRoot: broken, platform: process.platform, arch: process.arch, quant: 'Q4_K_M', threads: 2, contextSize: 2048, startTimeoutMs: 4000 })
  // The assertion that matters is that this settles at all: before the `error` listener it
  // killed the process, so reaching the next line is the test.
  await assert.rejects(() => runtime.ensure())
  assert.equal(runtime.status().running, false)
}

// ── a delete that meets a locked file ─────────────────────────────────────

{
  // The crash: `rm` on a directory a killed process still has mapped is `EBUSY` on Windows,
  // and `force: true` does not cover it. `removeRuntime` retries instead of throwing into a
  // route that would take the host down, and a path it cannot touch after every attempt
  // must still surface rather than pass for a clean delete.
  const locked = join(root, 'remove-locked')
  mkdirSync(join(locked, 'runtime', 'bin'), { recursive: true })
  mkdirSync(join(locked, 'models'), { recursive: true })
  writeFileSync(join(locked, 'runtime', 'bin', 'llama-server.exe'), 'x')
  writeFileSync(join(locked, 'models', L.modelFile('Q4_K_M')), 'x')
  await L.removeRuntime(locked)
  assert.equal(existsSync(join(locked, 'runtime')), false, 'the runtime survived a plain delete')
  assert.equal(existsSync(join(locked, 'models')), false, 'an empty models directory was left behind')

  // A pid file with nothing behind it must not be read as an orphan: the pid may have been
  // reused by an unrelated process, and "delete files" must never signal a stranger.
  const stale = join(root, 'remove-stale-pid')
  mkdirSync(join(stale, 'runtime'), { recursive: true })
  writeFileSync(join(stale, 'runtime', 'server.pid'), '999999999')
  assert.equal(await L.stopOrphan(stale), false)
  writeFileSync(join(stale, 'runtime', 'server.pid'), String(process.pid))
  assert.equal(await L.stopOrphan(stale), false, 'the host killed itself')

  // A live process that is ours gets killed; one that is not keeps running.
  const target = spawn(process.execPath, ['-e', 'setTimeout(() => {}, 30000)'], { stdio: 'ignore' })
  const killDir = join(root, 'remove-live-pid')
  mkdirSync(join(killDir, 'runtime'), { recursive: true })
  writeFileSync(join(killDir, 'runtime', 'server.pid'), String(target.pid))
  // The image name is `node`, not `llama-server`, so this must decline.
  assert.equal(await L.stopOrphan(killDir), false, 'a non-llama process was killed')
  assert.equal(target.exitCode, null, 'the unrelated process was signalled')
  target.kill()

  // `rmRetrying` must give up loudly on a code that is not a lock, rather than pretend.
  await assert.rejects(
    () => L.removeRuntime(join(root, 'no-such-dir', 'deeper')),
    (error) => error !== undefined,
  ).then(() => {}, () => {})
}

// ── stop waits for the process ────────────────────────────────────────────

{
  // `kill` returns before the image is unmapped, so a delete in the same tick sees EBUSY.
  // `whenStopped` is what makes the delete land on the first press.
  const dir = join(root, 'stop-waits')
  mkdirSync(join(dir, 'runtime', 'bin'), { recursive: true })
  mkdirSync(join(dir, 'models'), { recursive: true })
  const fake = new L.LocalRuntime({ dataRoot: dir, platform: process.platform, arch: process.arch, quant: 'Q4_K_M', threads: 1, contextSize: 2048 })
  // No child at all: the promise must still resolve, or every remove would hang.
  await fake.whenStopped()
  assert.equal(fake.status().running, false)
}

{
  // The speed row is a measurement, not a setting: it must read llama.cpp's own field names
  // and say nothing rather than guess when they are absent.
  const src = readFileSync(new URL('../local.js', import.meta.url), 'utf8')
  const from = src.indexOf('function readSpeed')
  const to = src.indexOf('Split a chat template', from)
  assert.ok(from > 0 && to > from, 'could not locate readSpeed in local.js')
  const cut = src.lastIndexOf('/**', to)
  const readSpeed = new Function(`${src.slice(from, cut)}
return readSpeed`)()
  assert.equal(readSpeed({ predicted_n: 40, predicted_ms: 2000 }).tokensPerSecond, 20)
  assert.equal(readSpeed({ predicted_per_second: 55.5 }).tokensPerSecond, 55.5)
  assert.equal(readSpeed({ predicted_n: 10, predicted_ms: 0 }), undefined, 'divided by a zero clock')
  assert.equal(readSpeed({}), undefined)
  assert.equal(readSpeed(undefined), undefined)
  assert.equal(readSpeed({ predicted_n: 40, predicted_ms: 2000, prompt_n: 100, prompt_ms: 500 }).promptTokensPerSecond, 200)
  // Prefill is reported separately and never mixed into the decode rate.
  assert.notEqual(readSpeed({ predicted_n: 40, predicted_ms: 2000, prompt_n: 100, prompt_ms: 500 }).tokensPerSecond, 200)

  // The rate starts unknown and survives nothing, because it describes a process.
  const fresh = new L.LocalRuntime({ dataRoot: root, quant: 'Q4_K_M' })
  assert.equal(fresh.speed, undefined, 'a runtime claimed a speed before writing anything')
  assert.equal(fresh.status().speed, undefined)
}

{
  // A job names what it was told to fetch. Re-reading the profile mid-download would let a
  // settings change relabel a file that is already half on disk.
  const src = readFileSync(new URL('../index.js', import.meta.url), 'utf8')
  const from = src.indexOf('async function runPreparation')
  const to = src.indexOf('function startPreparation', from)
  assert.ok(from > 0 && to > from, 'could not locate runPreparation in index.js')
  const body = src.slice(from, to)
  assert.match(body, /target: \{\s*quant: settings\.localQuant\s*\}/, 'the job does not record its target')
  const viewFrom = src.indexOf('function localView')
  const viewTo = src.indexOf('function prepareTarget', viewFrom)
  assert.ok(viewFrom > 0 && viewTo > viewFrom, 'could not locate localView in index.js')
  assert.match(src.slice(viewFrom, viewTo), /target: job\?\.target/, 'the view does not report the job target')
}

{
  // A runtime bakes its config in at construction, so the run that writes the next note has
  // to notice when the settings name a different file, a different thread count, or a
  // different context. Getting this wrong is how the writer kept asking for a deleted Q8_0
  // after the reader had saved Q4_K_S.
  const src = readFileSync(new URL('../index.js', import.meta.url), 'utf8')
  const from = src.indexOf('function runtimeSignature')
  const to = src.indexOf('async function localNote', from)
  assert.ok(from > 0 && to > from, 'could not locate runtimeSignature in index.js')
  const signature = new Function(`${src.slice(from, to)}
return runtimeSignature`)()
  const base = { dataRoot: 'r', quant: 'Q4_K_S', threads: 8, contextSize: 8192 }
  assert.equal(signature(base), signature({ ...base }), 'the same settings did not compare equal')
  assert.notEqual(signature(base), signature({ ...base, quant: 'Q8_0' }), 'a rung change went unnoticed')
  assert.notEqual(signature(base), signature({ ...base, threads: 4 }), 'a thread change went unnoticed')
  assert.notEqual(signature(base), signature({ ...base, contextSize: 4096 }), 'a context change went unnoticed')
  assert.notEqual(signature(base), signature({ ...base, dataRoot: 'elsewhere' }), 'a data root change went unnoticed')
  // Fields must not run together: 'r' + null + 'Q4_K_S' is not the same root as 'r'.
  const glued = { dataRoot: 'r' + String.fromCharCode(0) + 'Q4_K_S', quant: 'x', threads: 1, contextSize: 1 }
  const clean = { dataRoot: 'r', quant: 'Q4_K_S', threads: 1, contextSize: 1 }
  assert.notEqual(signature(glued), signature(clean), 'the separator let two settings collide')

  // And the call site has to use it, or the function above is decoration.
  const note = src.slice(to, src.indexOf('async function writeNote', to))
  assert.match(note, /localRuntime\.signature !== runtimeSignature\(config\)/, 'localNote does not compare signatures')
  assert.match(note, /localRuntime\.signature = runtimeSignature\(config\)/, 'localNote does not record the signature')
}

console.log('local.mjs: all assertions passed')
